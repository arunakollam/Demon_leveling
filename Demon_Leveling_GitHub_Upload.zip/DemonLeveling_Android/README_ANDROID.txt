Demon Leveling — Android project (phone-build ready)

This project is a native Android WebView app wrapping the offline Demon Leveling UI.

Included:
- Offline local training data
- Four themes
- Calendar
- Detailed progress graphs
- Level-up animations
- Research task
- Custom task creation/removal in Settings
- Six selectable launcher icons in Settings
- Native Android launcher-icon switching bridge
- Java 17 compile configuration

Build requirements:
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17+
- Android SDK platform 35 / Build Tools 34+

Phone build:
1. Open this folder as a Gradle Android project in a current Android IDE that supports AGP 8.x.
2. Allow the IDE to download/sync Gradle and Android SDK components.
3. Build the app using the Debug/Assemble Debug action.
4. Install the generated app-debug.apk.

Important:
- The app is fully offline after installation; training data is stored in WebView localStorage.
- Selecting an icon in Settings calls the native Android bridge and switches the enabled launcher alias.
- Some Android launchers cache icons. If the icon appears unchanged immediately, restart the launcher or phone.
