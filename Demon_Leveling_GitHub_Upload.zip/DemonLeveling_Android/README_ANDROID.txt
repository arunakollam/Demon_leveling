Demon Leveling — Android project (phone-build ready)

This project is a native Android WebView app wrapping the offline Demon Leveling UI.

Included:
- Offline local training data
- Four themes
- Calendar
- Detailed progress graphs
- Level-up animations
- Research task
- Custom task creation/removal in Settings
- Six selectable launcher icons in Settings
- Native Android launcher-icon switching bridge
- Java 17 compile configuration

Build requirements:
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17+
- Android SDK platform 35 / Build Tools 34+

Phone build:
1. Open this folder as a Gradle Android project in a current Android IDE that supports AGP 8.x.
2. Allow the IDE to download/sync Gradle and Android SDK components.
3. Build the app using the Debug/Assemble Debug action.
4. Install the generated app-debug.apk.

Important:
- The app is fully offline after installation; training data is stored in WebView localStorage.
- Selecting an icon in Settings calls the native Android bridge and switches the enabled launcher alias.
- Some Android launchers cache icons. If the icon appears unchanged immediately, restart the launcher or phone.


Version 2.0 changes
- Player Level is based only on Skill + Intelligence training time.
- 10 hours = 1 Player Level; Level 100 = 1,000 total hours.
- Player ranks: D Rank, C Rank, B Rank, A Rank, S Rank, Awakening, Fearless, Master, Grandmaster, Monarch, SuperConsciousness, BestInTheWorld, King of Hell, HonoredOne. Monarch starts at Level 50 and HonoredOne is Level 100.
- Body tasks, including custom Body tasks, never contribute to Player Level. They use separate day-based task levels.
- +1h and +1m buttons were resized/aligned for small phone screens.
- Weekly task table shows every task and the current week's training.
- Launcher icon selection only runs when a different icon is explicitly selected; opening Home or Settings does not call the launcher icon bridge.
