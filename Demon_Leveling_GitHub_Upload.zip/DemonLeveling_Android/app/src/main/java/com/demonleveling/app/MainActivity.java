package com.demonleveling.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    private static final String[] ALIASES = {
            "LauncherDefault", "LauncherCore", "LauncherFlame",
            "LauncherShadow", "LauncherTarget", "LauncherBolt"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public static class AndroidBridge {
        private final Context context;

        AndroidBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @android.webkit.JavascriptInterface
        public void setLauncherIcon(String name) {
            String selected = "LauncherDefault";
            if ("core".equals(name)) selected = "LauncherCore";
            else if ("flame".equals(name)) selected = "LauncherFlame";
            else if ("shadow".equals(name)) selected = "LauncherShadow";
            else if ("target".equals(name)) selected = "LauncherTarget";
            else if ("bolt".equals(name)) selected = "LauncherBolt";

            SharedPreferences prefs = context.getSharedPreferences("launcher_icon", Context.MODE_PRIVATE);
            String previous = prefs.getString("selected", "LauncherDefault");
            if (selected.equals(previous)) return;

            PackageManager pm = context.getPackageManager();
            String pkg = context.getPackageName();

            // Only touch the launcher aliases when the user explicitly chooses a different icon.
            for (String alias : ALIASES) {
                ComponentName component = new ComponentName(pkg, pkg + "." + alias);
                int state = alias.equals(selected)
                        ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
                int current = pm.getComponentEnabledSetting(component);
                if (current != state) {
                    pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP);
                }
            }
            prefs.edit().putString("selected", selected).apply();

        }
    }
}
