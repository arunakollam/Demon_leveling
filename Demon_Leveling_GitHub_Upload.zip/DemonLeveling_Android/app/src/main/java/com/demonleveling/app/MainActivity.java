package com.demonleveling.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private View statusBarBackground;
    private View statusBarBottomLine;

    private static final String[] ALIASES = {
            "LauncherDefault", "LauncherCore", "LauncherFlame",
            "LauncherShadow", "LauncherTarget", "LauncherBolt"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        // Keep edge-to-edge so the existing bottom navigation can remain immersive,
        // but reserve a real native area for the Android status bar at the top.
        // Match the footer exactly: deep navy background, with a thin blue border at the bottom.
        window.setStatusBarColor(Color.rgb(5, 10, 18));
        window.setNavigationBarColor(Color.rgb(5, 10, 18));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 9, 20));

        // This is NOT an extra HTML header. It is only the background behind the
        // real Android clock/battery/status icons. Its height exactly matches the
        // phone's status-bar inset, so it can never overlap the app header.
        statusBarBackground = new View(this);
        // Same fill as the fixed footer (#050a12), with no gradient.
        statusBarBackground.setBackgroundColor(Color.rgb(5, 10, 18));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, Gravity.TOP);
        root.addView(statusBarBackground, statusParams);

        // Footer uses a 1px #173047 top border. Mirror it at the bottom of the status area.
        statusBarBottomLine = new View(this);
        statusBarBottomLine.setBackgroundColor(Color.rgb(23, 48, 71));
        FrameLayout.LayoutParams lineParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1, Gravity.TOP);
        root.addView(statusBarBottomLine, lineParams);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 9, 20));
        webView.setFitsSystemWindows(false);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.TOP);
        root.addView(webView, webParams);

        root.setOnApplyWindowInsetsListener((View v, WindowInsets insets) -> {
            int top;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                top = insets.getInsets(WindowInsets.Type.statusBars()).top;
            } else {
                top = insets.getSystemWindowInsetTop();
            }

            // Native status-bar background occupies the complete status-bar area.
            ViewGroup.LayoutParams sp = statusBarBackground.getLayoutParams();
            sp.height = top;
            statusBarBackground.setLayoutParams(sp);

            // The matching 1px blue line is the BOTTOM border of the status/header area.
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) statusBarBottomLine.getLayoutParams();
            lp.height = 1;
            lp.topMargin = Math.max(0, top - 1);
            statusBarBottomLine.setLayoutParams(lp);

            // Move the EXISTING HTML header below the real status bar.
            // No fake black strip is inserted into the web page.
            FrameLayout.LayoutParams wp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            wp.topMargin = top;
            wp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            webView.setLayoutParams(wp);
            return insets;
        });

        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public static class AndroidBridge {
        private final Context context;

        AndroidBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @android.webkit.JavascriptInterface
        public void setLauncherIcon(String name) {
            String selected = "LauncherDefault";
            if ("core".equals(name)) selected = "LauncherCore";
            else if ("flame".equals(name)) selected = "LauncherFlame";
            else if ("shadow".equals(name)) selected = "LauncherShadow";
            else if ("target".equals(name)) selected = "LauncherTarget";
            else if ("bolt".equals(name)) selected = "LauncherBolt";

            android.content.SharedPreferences prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE);
            String previous = prefs.getString("selected", "default");
            if (name == null || name.equals(previous)) return;

            PackageManager pm = context.getPackageManager();
            String pkg = context.getPackageName();

            for (String alias : ALIASES) {
                ComponentName component = new ComponentName(pkg, pkg + "." + alias);
                int state = alias.equals(selected)
                        ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
                pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP);
            }

            prefs.edit().putString("selected", name).apply();
        }
    }
}
