package com.demonleveling.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    private static final String[] ALIASES = {
            "LauncherDefault", "LauncherCore", "LauncherFlame",
            "LauncherShadow", "LauncherTarget", "LauncherBolt"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Android 15+ targets API 35 with edge-to-edge enabled.
        // Demon Leveling intentionally keeps its bottom navigation edge-to-edge,
        // but the app header must start below the real Android status bar.
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.rgb(5, 10, 18));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 9, 20));
        webView.setFitsSystemWindows(false);
        // The HTML now owns the top safe-area/header. Do not add padding to the
        // WebView itself, otherwise the status-bar strip and app header would be
        // pushed down twice on edge-to-edge devices.
        webView.setOnApplyWindowInsetsListener((View v, WindowInsets insets) -> insets);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public static class AndroidBridge {
        private final Context context;

        AndroidBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @android.webkit.JavascriptInterface
        public void setLauncherIcon(String name) {
            String selected = "LauncherDefault";
            if ("core".equals(name)) selected = "LauncherCore";
            else if ("flame".equals(name)) selected = "LauncherFlame";
            else if ("shadow".equals(name)) selected = "LauncherShadow";
            else if ("target".equals(name)) selected = "LauncherTarget";
            else if ("bolt".equals(name)) selected = "LauncherBolt";

            android.content.SharedPreferences prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE);
            String previous = prefs.getString("selected", "default");
            if (name == null || name.equals(previous)) return;

            PackageManager pm = context.getPackageManager();
            String pkg = context.getPackageName();

            for (String alias : ALIASES) {
                ComponentName component = new ComponentName(pkg, pkg + "." + alias);
                int state = alias.equals(selected)
                        ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
                pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP);
            }

            prefs.edit().putString("selected", name).apply();
        }
    }
}
